# CHARACTER BIBLE — [NAME]
### Project: [PROJECT NAME] | Role: [Protagonist / Mentor / Antagonist / Collateral]

---

## Basic Identity

- **Full Name:**
- **Archetype:**
- **Role:**
- **Story Function:**

---

## Physical Description
*(For AI image generation — be specific, descriptors become prompts)*

- Age and build:
- Facial features:
- How they move:
- Clothing:
- Power visual (speed trail, aura, etc.):
- At key story moments (beginning vs end):

---

## Psychological Profile

---

## Core Wound

*One sentence. The thing that made them.*

---

## Philosophy (In Their Own Words)

> "[Quote that captures how they see the world]"

> "[Quote that reveals what they justify]"

---

## How They Justify Everything

Numbered logical steps from inside their perspective:

1.
2.
3.
4.
5.

---

## Turning Point

*The scene where everything changes — what happens, what it costs.*

---

## Fatal Flaw

*The thing that makes their logic collapse — even if they never see it.*

---

## The Ending

*How their story ends. What they are in the final frame.*

---

## AI Image Prompts

**Full Body — Early Story:**
```
[Paste complete prompt here]
```

**Full Body — Late Story:**
```
[Paste complete prompt here]
```

**Portrait — Key Emotional Moment:**
```
[Paste complete prompt here]
```

**Action / Power:**
```
[Paste complete prompt here]
```

**The Final Scene:**
```
[Paste complete prompt here]
```
