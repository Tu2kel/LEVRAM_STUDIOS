# LEVRAM STUDIOS — Writing Rules

---

## The Non-Negotiables

### 1. Emotion Over Action
Every scene exists to make the audience FEEL something specific.
Before writing any scene, answer: *What is the emotional purpose of this scene?*
If the answer is "it looks cool" — rewrite the premise.

### 2. Atmosphere Over Spectacle
The dread before the event matters more than the event.
The silence after the explosion matters more than the explosion.
What the character does not say matters more than what they do.

### 3. Psychological Consequence Over Choreography
Powers are not interesting. What powers DO TO A PERSON is interesting.
A fight scene is only worth writing if something breaks inside someone during it.

### 4. Powers Are Terrifying, Not Cool
Speed means you watch everyone you love move in slow motion until they die.
Strength means every handshake is a calculation. Every embrace is a threat.
Immortality means you remember everyone. Everyone forgets you.
Write powers as the horror they actually are.

---

## Dialogue Rules

- Every line must carry weight. If a line can be cut without losing meaning — cut it.
- Characters do not explain themselves to the audience. They speak to each other.
- The most important things are said quietly, not loudly.
- Monologues are earned. A character earns a monologue through silence first.
- No quips. No one-liners. No Marvel timing. This is not that world.
- Subtext is always present. Characters rarely say what they actually mean.

**Example of wrong dialogue:**
> "I'm going to destroy you because you left me behind and now I'm powerful!"

**Example of right dialogue:**
> "You never asked what happened after you left."
> *[pause]*
> "That's all I needed to know."

---

## Villain Writing Rules

- Write the villain's POV FIRST. Before the hero. Before the plot.
- The villain's logic must be airtight from inside their perspective.
- Never let another character dismiss the villain's argument without cost.
- The villain should be right about at least one important thing.
- Show the villain doing something genuinely good, early. Make the audience like them.
- The horror comes from watching good logic produce terrible outcomes.

---

## Hero Writing Rules

In LEVRAM, heroes are forces of nature — not saviors.

- Heroes are never the protagonist of a LEVRAM story
- Heroes cause collateral damage without awareness
- Heroes are shown from the perspective of those they don't save
- Heroes are not evil — they are simply too large to see individuals
- The most devastating thing a hero can do is nothing wrong

---

## Scene Structure

Every scene needs:
1. **An emotional entry point** — where are we in this character's psychology right now
2. **A shift** — something changes, is revealed, or breaks
3. **An emotional exit point** — where are we now that we weren't before

A scene where nothing changes inside a character is not a scene. It is coverage.

---

## What To Never Write

- Cheesy Marvel-style humor or ironic detachment
- A villain explaining their plan to the hero
- A hero speech that resolves emotional conflict
- Powers used without psychological cost
- A redemption arc that erases consequence
- Destruction without civilian aftermath
- A ending that feels earned by the plot but not by the character's soul

---

## Tone Reference Points

When in doubt, ask: does this feel like any of these?

- *No Country for Old Men* — inevitability, quiet dread
- *Requiem for a Dream* — escalating consequence, no escape
- *Man of Steel* — mythological scale, civilian perspective on power
- *Blade Runner 2049* — philosophical loneliness, visual patience
- *Watchmen* — ideology examined until it breaks
- *Annihilation* — the horror of something beyond human comprehension

If it feels like *The Avengers* — rewrite it.
