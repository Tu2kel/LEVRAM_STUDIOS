# SCENE BREAKDOWN — [SCENE NUMBER / TITLE]
### Project: [PROJECT] | Act: [1/2/3]

---

## Scene Info

- **Scene Number:**
- **Location:**
- **Time of Day:**
- **Characters Present:**
- **Duration Estimate:**

---

## Emotional Purpose

*What is this scene ACTUALLY about? Not what happens — what does the audience feel?*

---

## What Happens

*Beat by beat — keep it clean, no fluff*

1.
2.
3.
4.

---

## Key Dialogue

```
CHARACTER: "Line"

CHARACTER: "Line"

CHARACTER: "Line"
```

*[Note: what's NOT said matters as much as what is]*

---

## Camera Direction

- **Opening shot:**
- **Key camera moves:**
- **Focal point during emotional peak:**
- **Closing shot:**

---

## Color / Light Notes

---

## Sound / Silence Notes

*When does silence happen? What does it mean?*

---

## AI Image Prompt — This Scene

```
[Complete image prompt for generating a still from this scene]
```

---

## AI Video Prompt — This Scene

```
CAMERA:
MOVEMENT:
SUBJECT:
ENVIRONMENT:
PACE:
SOUND:
DURATION:
```

---

## Transitions

- **Comes after:**
- **Leads into:**
- **Emotional bridge:**
