# LEVRAM STUDIOS — Visual Identity Guide

---

## Overall Aesthetic

> *Blade Runner meets Man of Steel. Cosmic loneliness meets urban consequence.*

Every visual choice must serve the emotional truth of the scene.
No spectacle without consequence. No beauty without weight.

---

## Color Language Per Project

### The Runner
- **Primary:** Cold blue-white
- **Secondary:** Deep void black
- **Accent:** Electric white speed trails
- **Meaning:** Speed as ice. Time as emptiness. Transcendence as cold.
- **Reference mood:** The silence after a thunderclap.

### The Other Side
- **Primary:** Warm amber — like firelight, like nostalgia
- **Secondary:** Ash grey — what the fire becomes
- **Accent:** Flickers of red when ideology turns to violence
- **Meaning:** Belief that was once warm, slowly turning to ruin.
- **Reference mood:** A photograph of someone you used to trust.

### Levram Banner (Marcus)
- **Primary:** Deep space black — absolute, suffocating
- **Secondary:** Violent biological green — the rage entity
- **Accent:** Supernova red — death, rebirth, the blast
- **Meaning:** Infinite darkness broken only by violence and biology.
- **Reference mood:** Drowning slowly. Waking up. Drowning again.

---

## Environment Design

### Cities
- Always at night or overcast
- Neon reflecting off wet pavement
- Scale shown through civilian smallness — a person dwarfed by rubble
- Destruction scenes always include: smoke, abandoned objects, silence after chaos
- No clean skylines. Every building has history.

### Cosmic / Space Sequences
- Near-total darkness with single light sources
- Stars as distance, not beauty
- The character is always small against the frame
- No sound — or a single low frequency tone
- Time shown through visual decay — stars aging, entropy visible

### Speed Sequences
- The world does not move faster — it **freezes**
- Humans caught mid-motion look like statues, not actors
- Speed trails are cold white-blue, not warm yellow
- The speedster's face is the only thing in focus — everything else smears
- Environment destruction from speed shown in slow motion aftermath

---

## Camera Philosophy

| Scene Type | Camera Behavior |
|---|---|
| Emotional dialogue | Slow push-in. Uncomfortably close. Hold. |
| Speed movement | Violent cuts. World blurs. Disorienting. |
| Cosmic sequences | Near-static. Vast. Character is a speck. |
| Psychological breakdown | Invasive close-up. Handheld slight shake. |
| City destruction | Ground level. Civilian POV. Never from above. |
| Final frames | Hold longer than comfortable. Let silence work. |

---

## Destruction Scenes — Required Elements

When any battle or power use destroys an environment, the following MUST appear:
- At least one civilian trapped or fleeing
- A child or family separated
- Emergency sirens in the distance (no one coming)
- Smoke rising from a building that had people in it
- The hero/powered character NOT looking back
- The aftermath — empty streets, broken glass, someone crying quietly

This is non-negotiable. Every use of power has a cost the powerful never see.

---

## Lighting Rules

- Natural light = humanity, warmth, the past (used sparingly — for flashbacks, origin moments)
- Artificial light = isolation, power, the present
- Darkness = transcendence, loss of humanity, the point of no return
- A character moving FROM natural light INTO artificial light is always a fall, even if they don't know it yet

---

## Final Frame Rule

Every LEVRAM story ends on a face.
No speech. No score swell. No explanation.
Just the weight of what they became — held until the audience feels it.
Then black. Then title.
Minimum three seconds of black before anything else.
