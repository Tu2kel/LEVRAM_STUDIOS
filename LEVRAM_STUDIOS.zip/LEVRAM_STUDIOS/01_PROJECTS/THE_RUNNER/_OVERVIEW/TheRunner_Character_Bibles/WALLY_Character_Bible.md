# CHARACTER BIBLE — WALLY
### Project: The Runner | Role: Protagonist / Villain

---

## Basic Identity

- **Full Name:** Wally (last name withheld — he stopped using it)
- **Archetype:** The Neglected Disciple / The Transcendent
- **Role:** Protagonist. The audience follows him completely. He is never framed as the villain until the camera pulls back.
- **Story Function:** The cost of speed. The cost of admiration given to someone unworthy of it. The cost of becoming something no longer human.

---

## Physical Description
*(For AI image generation)*

- Late 20s, lean and angular — not muscular, wiry
- Dark skin, close-cut hair, sharp eyes that look slightly ahead of wherever they're pointed
- Moves with unnatural stillness when not running — like something that has already calculated every possible movement and decided not to bother
- Clothing: dark, minimal, no insignia — a person who stopped caring about being seen
- At full speed: visible only as heat distortion and a cold blue-white trail
- At the End of Time: same appearance, but lit by nothing — only visible because everything else is darker

---

## Psychological Profile

Wally was never broken by cruelty. He was broken by **admiration met with indifference.**

He looked at Barry and saw potential so vast it was almost a moral obligation. He assumed Barry saw it too. He assumed greatness recognized greatness and would reach back to pull him forward.

Barry never reached back.

So Wally ran. Alone. Further and faster than Barry ever went. And every threshold he crossed, he felt the distance between himself and humanity grow — not as loss, but as clarity. The slower world started to feel like noise. People started feeling like temporary arrangements of matter. Morality started feeling like a rule invented by creatures who didn't have enough time to think past it.

He doesn't hate humans. That would require caring. He has simply... outpaced them.

---

## Core Wound

*He loved someone who never noticed.*

Not romantically. Spiritually. He gave Barry the worship a young person gives to the person they want to become — and Barry treated the gift like weather.

That wound doesn't turn into rage. It turns into something colder. A decision.

*If the people you admire are this small, then the only direction worth moving is past them.*

---

## Philosophy (In His Own Words)

> "Everyone acts like speed is a gift. Like I should be grateful. For what? For watching everyone I've ever known move in slow motion until they stopped moving at all? For understanding that time is a story humans tell themselves so the dying feels orderly?"

> "Barry had everything. He used it to avoid traffic. And everyone called him a legend. So what does that make me?"

> "I'm not running from anything. I stopped doing that a long time ago. I'm running *toward* the only question that ever mattered — what's at the end?"

---

## How He Justifies Everything

Wally's internal logic is clean and consistent:

1. Barry was given a gift and wasted it — this proves gifts are wasted on the comfortable
2. He, Wally, was willing to pay what Barry wasn't — this proves he earned what he has
3. The people he's hurt were obstacles in a race that matters more than they do
4. The faster he becomes, the more he can see that individual human lives are brief and statistically insignificant
5. He is not cruel. He is simply moving at a speed where cruelty and kindness are the same — too slow to matter

He is wrong. But the logic holds from inside it. That's the point.

---

## Turning Point

The moment Wally stops running from Death and turns to face it.

He has been running from something — an entity, a consequence, a reckoning — and he runs harder than he ever has. And then he stops. Turns. Faces it.

And Death cannot reach him.

Not because he's faster. Because he no longer exists inside the **moment** death requires. Death is a door at the end of a hallway. Wally no longer walks hallways.

This is the moment he stops being a person becoming a god — and becomes something with no category.

He doesn't celebrate. He stands in the place where time doesn't move and feels, for the first time, completely alone in a way no one has ever been alone before.

---

## Fatal Flaw

He confused transcendence with victory.

He reached the end of time. He outlasted death. He surpassed everything Barry was.

And it's completely silent.

There is no one to tell. No one to show. The only thing waiting at the end of everything is an ancient being who looks at him the way you look at weather.

He won the race. The race didn't care.

---

## The Killing of Barry

Not a fight. Not rage. Distance.

Wally finds Barry living the same life. Still comfortable. Still small. Still exactly what he always was.

And Wally feels nothing except the faint echo of who he used to be — the boy who thought Barry was the whole world.

He does what needs to be done. Slowly. The camera does not glorify it.

Before it ends, he holds Barry's face the way you hold a photograph of someone who has been dead for years.

> *"Thank you for showing me there was no finish line."*

He means it completely. He is not being cruel. He is being honest.

That is the tragedy.

---

## The Final Moment

Wally at the end of time. Alone. The ancient being has said its piece and fallen silent.

Nowhere left to run. Nothing left to surpass.

The camera pulls back until he is a single point of light in absolute darkness.

Then even that fades.

---

## AI Image Prompts

**Full Body — Early Story:**
Cinematic dark-superhero style, young Black man, late 20s, lean and angular, dark minimal clothing, standing at the edge of a rain-soaked neon city at night, looking forward with unsettling stillness, cold blue-white ambient light, Blade Runner aesthetic, Man of Steel color grade, photorealistic, tragic tone, no superhero costume, grounded realism

**Full Body — Late Story:**
Same character, older feeling despite same age, standing in absolute void space, no visible light source yet he is visible, cold blue-white outline, eyes that have seen too much, posture of someone who has nothing left to prove, existential weight, cinematic still, cosmic horror tone

**Portrait — The Turning Point:**
Extreme close-up, young Black man, the moment after realizing death cannot touch him, not triumph on his face — something colder, something lonelier, cold blue light from nowhere, eyes slightly unfocused as if looking at something that isn't there yet, photorealistic, emotionally devastating, cinematic

**Action — At Speed:**
Cinematic motion, dark city street frozen in time, pedestrians caught mid-step like statues, everything motion-blurred except a cold blue-white trail and one face in sharp focus — young Black man running, expression not exhilarated but blank, almost sad, neon reflections on wet pavement, slow-motion aftermath feel

**The Killing of Barry:**
Two men, one older one younger, dimly lit interior, the younger holding the older man's face with both hands, not violence — something like grief, cold blue light, close framing, no context needed, the weight of something inevitable, photorealistic, devastating quiet
