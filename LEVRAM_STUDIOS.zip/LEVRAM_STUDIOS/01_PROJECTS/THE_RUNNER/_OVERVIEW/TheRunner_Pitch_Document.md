# THE RUNNER — Pitch Document & World Lore
### LEVRAM STUDIOS | Project: The Runner

---

## Logline

A young man worships a legendary speedster who saves cities but wastes his gift — and in trying to become everything his mentor wasn't, loses the last thing that made him human.

---

## Tagline

*He didn't become a god. He became something lonelier.*

---

## The Story in One Paragraph

Wally grew up watching Barry — a man with supernatural speed who never became anything with it. Wally saw what Barry couldn't see in himself and spent his life trying to unlock it. As his speed grew, so did the distance between him and everything human. Conversations froze. Emotions arrived late. Time stopped feeling linear. People started feeling temporary. At the edge of his own annihilation, he outran death — not by escaping it, but by transcending the moment it requires. He ran to the end of time itself, where an ancient being greeted him like weather. And then he went back and found Barry — still comfortable, still small, still exactly what he always was — and did what he came to do. Not out of hatred. Out of transcendence. He thanked him before the end. He meant it. That's the tragedy.

---

## Themes

- **Speed as isolation:** The faster you move, the slower everyone else becomes, until they stop entirely.
- **Admiration as liability:** The people we worship shape us more than the people who love us.
- **Transcendence as loss:** Every threshold crossed leaves something human behind.
- **The wasted gift:** Is it a crime to have something extraordinary and use it small?
- **Time as the only real enemy:** Not death. Not enemies. The fact that everyone else runs out of it.

---

## Three-Act Structure

### ACT ONE — THE DISCIPLE
Establish Wally's relationship with Barry. The worship. The hope that Barry will one day reach back.
Barry never reaches back — not cruelly, just... never.
Wally's speed begins to emerge. He is faster than Barry already. He doesn't understand what's happening to his perception of time.
**End of Act One:** Wally realizes Barry is never going to become what Wally needed him to be. The decision is made — consciously or not — to become it himself.

### ACT TWO — THE ASCENSION
Wally pushes past every threshold. Each one costs something human.
Parallel scenes: early Wally trying to have normal moments (dinner, connection, stillness) vs. late Wally unable to tolerate them.
The world begins to feel like it's moving too slowly. People feel temporary.
**Key Sequence:** Wally is hunted. Runs. Pushes past the edge. Stops. Faces Death. Death cannot reach him.
The weight of what that means settles — not triumph. Silence. Absolute aloneness.

### ACT THREE — THE END OF EVERYTHING
Wally runs forward through time. Past civilization. Past the stars.
Reaches the end of time. Meets the ancient being.
The ancient being's message: *"The faster you become, the further you drift from humanity."*
Wally's response: *"I know."*
Returns. Finds Barry.
The ending we've already described.
Final frame. Black. Title.

---

## World Lore

### The Speed and Time
Speed in this world is not just physical. It is **perceptual.**
Once a speedster reaches a certain threshold, they begin experiencing time non-linearly — seeing probability threads, experiencing multiple seconds within one, feeling the weight of every timeline that didn't happen.
There is no upper limit. The faster you go, the further from causality you drift, until you exist *between* moments rather than inside them.
This is why Death cannot reach Wally at the end. Death operates on causality. Wally no longer does.

### The Ancient Being at the End of Time
Not a god. Not an enemy. Something that has watched every civilization in every timeline exhale its last breath.
It does not grieve. It does not celebrate.
It observes.
Wally is the first entity it has ever seen arrive on foot.
What that means is left for the audience to hold.

### Other Speedsters (Implied, Not Shown)
There have been others. The world has known people with this gift before.
None of them reached where Wally reached. The ancient being's line implies this — *"on foot"* means others may have arrived other ways, or not at all.
What happened to them is never addressed. That silence is intentional.

---

## YouTube Episode Structure

| Episode | Title | Content |
|---|---|---|
| EP01 | The Legend | Introduce Barry. The city loves him. Wally watches from below. |
| EP02 | The Gift | Wally's speed emerges. He can already feel the distance starting. |
| EP03 | The Freeze | Wally tries to live a normal life. Cannot. The world is too slow. |
| EP04 | The Hunt | Something comes for Wally. He runs harder than he ever has. |
| EP05 | The Turn | He stops. Faces it. Death recedes. The silence that follows. |
| EP06 | The Edge | Wally runs past the end of everything. The ancient being. |
| EP07 | The Return | He comes back. He finds Barry. |
| EP08 | The Finish Line | The ending. Barry's last expression. Wally alone at the end of time. |

---

## Soundtrack Emotional Direction

- **Early Wally scenes:** Sparse piano. Something hopeful trying to exist in cold air.
- **Speed sequences:** No melody. Low frequency drone. The sound of air at impossible velocity.
- **Barry scenes:** Warm brass. Nostalgic. The sound of something that used to be enough.
- **The Death encounter:** Complete silence, then a single tone so low it's felt not heard.
- **End of Time sequence:** Nothing. Absolute silence. Let the visual carry everything.
- **The killing of Barry:** Return of the early piano theme — but slower, wrong, like a music box running out of spring.
- **Final frame:** Silence. Three seconds. Then a tone that holds through the black screen.
