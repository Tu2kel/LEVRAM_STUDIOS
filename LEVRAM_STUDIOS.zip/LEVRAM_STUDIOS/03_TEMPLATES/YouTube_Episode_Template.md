# YOUTUBE EPISODE — [EPISODE TITLE]
### Project: [PROJECT] | Episode: [NUMBER]

---

## Episode Info

- **Episode Title:**
- **Episode Number:**
- **Story:**
- **Runtime Target:**
- **Upload Date:**

---

## The Hook (First 10 Seconds)

*What makes someone stay? Write it out exactly.*

---

## What This Episode Covers

*Scene by scene — what the viewer sees*

1.
2.
3.
4.
5.

---

## Key Scene for Thumbnail

*Which moment in this episode is the most visually striking?*

---

## Narration Style

- [ ] Wally voiceover (cold, measured, philosophical)
- [ ] Third-person cinematic narration
- [ ] Pure visual / no dialogue
- [ ] Character dialogue only

---

## Cliffhanger / Ending Note

*How does this episode end? What pulls them to the next one?*

---

## Thumbnail Prompt

```
[Complete AI image prompt optimized for thumbnail — high contrast, readable at small size]
```

**Text overlay:** `[TITLE TEXT ON THUMBNAIL]`
**Text position:** [Top / Bottom / Left / Right]

---

## Title Options

1.
2.
3.

**Selected:**

---

## Description Copy

```
[YouTube description — 150-300 words]

Hook line.

What this episode is about (no spoilers for the ending).

LEVRAM STUDIOS — [tagline]

#tags
```

---

## Tags

```
dark superhero, original story, LEVRAM Studios, villain POV, [character name], 
[project name], dark fiction, cinematic, AI generated, [episode theme]
```

---

## Pinned Comment

```
[Write the pinned comment that starts the conversation under the video]
```
