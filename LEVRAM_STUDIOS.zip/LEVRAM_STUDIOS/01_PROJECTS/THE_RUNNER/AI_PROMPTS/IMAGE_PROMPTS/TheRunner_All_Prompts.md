# THE RUNNER — AI Prompt Master Sheet
### LEVRAM STUDIOS | Ready to paste into Midjourney, DALL-E, Runway, Sora, etc.

---

## HOW TO USE THIS FILE

Each prompt is labeled with the tool it's optimized for.
**[IMG]** = Image generators (Midjourney, DALL-E, Stable Diffusion)
**[VID]** = Video generators (Runway Gen-3, Sora, Kling)
**[THUMB]** = YouTube thumbnail optimized

Paste the FULL PROMPT including all descriptors.
For Midjourney add: `--ar 16:9 --style raw --v 6` at the end of image prompts.
For cinematic video prompts include camera direction in your tool's motion settings.

---

# CHARACTER PROMPTS

## WALLY

**[IMG] — Character Sheet / First Look**
```
Young Black man, late 20s, lean angular build, dark minimal clothing with no insignia, 
standing at the edge of a rain-soaked neon city at night, looking forward with unsettling 
stillness, cold blue-white ambient light, wet pavement reflections, Blade Runner aesthetic, 
Man of Steel color grade, photorealistic, cinematic tragedy tone, no superhero costume, 
grounded realism, full body shot, 8k
```

**[IMG] — Wally at Speed**
```
Dark city street frozen in time, pedestrians caught mid-step like statues, motion blur 
on everything except one figure, young Black man running through frozen crowd, cold 
blue-white speed trail, expression not exhilarated but blank, almost sad, neon reflections 
on wet pavement, slow-motion aftermath feel, cinematic, Blade Runner color palette, 
photorealistic, 8k
```

**[IMG] — Wally After Facing Death**
```
Extreme close-up portrait, young Black man, aftermath of transcendence on his face, 
not triumph — something colder, lonelier, cold blue light from no visible source, eyes 
slightly unfocused as if seeing something beyond the frame, the expression of someone 
who just understood they cannot die and found no comfort in it, photorealistic, 
cinematically devastating, dark background
```

**[IMG] — Wally at End of Time**
```
Single figure standing in absolute void, no visible light source but figure is visible, 
young Black man in dark minimal clothing, cold blue-white outline light, posture of 
someone who has nothing left to prove, existential weight, the size of the void 
dwarfing the figure, cosmic horror tone, cinematic still, terrifying loneliness, 8k
```

---

## BARRY

**[IMG] — Barry the Legend**
```
Older Black man, late 40s, warm build, lived-in comfortable clothing, standing on a 
city street at dusk, warm amber light, relaxed posture, the ease of a man who has 
never questioned belonging, slight smile, photorealistic, cinematic, contrast to cold 
blue world of Wally, grounded realism, full body, 8k
```

**[IMG] — Barry Portrait**
```
Close-up portrait, older Black man, warm face, slight smile that doesn't reach the eyes, 
warm golden light from left, soft focus city street background, the face of a man who 
chose enough and meant it, photorealistic, bittersweet emotional tone, cinematic
```

**[IMG] — Barry's Last Moment**
```
Extreme close-up, older Black man's face being held by two hands barely visible at 
frame edges, expression shifting from confusion to recognition to something like peace 
arriving too late, warm amber light dying at the edges, photorealistic, devastating, 
cinematic tragedy, the last thing he understood
```

---

# ENVIRONMENT PROMPTS

**[IMG] — The City (Establishing)**
```
Dark neon metropolis at night, rain-soaked streets, reflections of blue and amber 
neon in puddles, scale of buildings dwarfing street level, one small figure visible 
below, smoke from a distant fire, Blade Runner meets Man of Steel aesthetic, 
photorealistic, cinematic wide shot, cold color grade, 8k
```

**[IMG] — The End of Time**
```
The literal end of existence, entropy made visual, no stars — they have all gone dark, 
no planets, absolute void broken only by the faint suggestion of something that 
used to be light, two figures visible at the very edge of the frame — one ancient and 
still, one recently arrived, cosmic horror scale, near-total darkness, photorealistic 
rendering of nothing, 8k
```

**[IMG] — The Speed Force / Between Moments**
```
Abstract environment between moments in time, fractured light like broken glass but 
made of seconds, blue-white fragments of frozen events floating in void, figure 
standing in center completely still while everything around mid-motion, dreamlike 
visual language, cinematic, cold color palette
```

**[IMG] — City Destruction Civilian POV**
```
Ground level view of city block mid-destruction, camera at civilian eye level, rubble 
falling, a child alone on a sidewalk, adults running in background, smoke rising from 
building, emergency vehicle lights in distance, no superhero visible — only the 
aftermath of power, photorealistic, Man of Steel civilian destruction reference, 
emotionally devastating, natural light through smoke
```

---

# KEY SCENE PROMPTS

**[IMG] — Outrunning Death**
```
Young Black man running at impossible speed, something dark and formless behind him 
unable to keep pace, cold blue-white speed trail, the entity of death rendered as 
negative space and shadow, dark environment, motion blur on everything except his 
face which is in sharp focus, expression of someone running out of desperation not 
strength, cinematic, photorealistic
```

**[IMG] — The Turn (Facing Death)**
```
Young Black man standing completely still, facing camera, back to the direction he 
was running, a massive dark presence behind him that has stopped, unable to move 
forward, cold blue light, the moment after understanding that death cannot reach him, 
expression of absolute aloneness not triumph, wide shot showing the scale of both 
figures, cinematic, devastating quiet
```

**[IMG] — The Killing of Barry**
```
Two men, older and younger, interior space, dim warm light at the edges dying to 
cold, younger man holding older man's face with both hands, no violence visible — 
something like grief expressed as action, the younger man's eyes closed or nearly 
so, intimate framing, the weight of something inevitable, photorealistic, quiet 
devastation, no context needed
```

---

# VIDEO PROMPTS

**[VID] — Opening Shot**
```
CAMERA: Aerial, slowly descending toward a rain-soaked city at night
MOVEMENT: Slow and heavy, like something enormous looking down
ENVIRONMENT: Dark neon city, wet streets, amber and blue reflections
SUBJECT: Finding a single small figure standing still on an empty street
PACE: Extremely slow. 30 seconds minimum for this descent.
SOUND DIRECTION: Near silence. Distant city ambience. A single low tone.
MOOD: A god looking at the world before deciding what to do with it
```

**[VID] — Speed Sequence**
```
CAMERA: Locked on subject's face, everything else in violent motion blur
MOVEMENT: Camera slightly handheld — the world shaking around a still face
SUBJECT: Young man running, expression blank, eyes tracking something ahead
ENVIRONMENT: City street, pedestrians frozen mid-step, world turned to smear
SPEED TRAIL: Cold blue-white, ice-like, not warm
PACE: Violently fast cuts between frozen world and motion-blur world
SOUND: No music. Only the sound of air being displaced at impossible speed.
```

**[VID] — The Turn (Facing Death)**
```
CAMERA: Starts behind the running figure, slowly pushing forward
MOVEMENT: Figure slows. Stops. Pause. Then slowly turns to face camera.
BEHIND HIM: A massive dark presence that also stops.
HOLD: Camera holds on face for 8-10 full seconds. Do not cut.
LIGHT: Cold blue light. Single source. No warmth anywhere.
SOUND: Complete silence. Then a single tone so low it's felt not heard.
PACE: The slowest this film has been. Let the silence be a presence.
```

**[VID] — End of Time Arrival**
```
CAMERA: Wally running, camera pulling back, back, back — until he is tiny
ENVIRONMENT: The world around him aging and collapsing as he passes through time
STARS: Going out one by one as he passes
ARRIVING: The void. He stops. The ancient figure is there.
CAMERA: Now extremely close. Their faces. Nothing else.
SOUND: Nothing. Absolute nothing.
HOLD: 15 seconds of silence after they meet before anyone speaks.
```

**[VID] — Teaser Trailer (60 seconds)**
```
0:00-0:10 — Black screen. A single sound: footsteps. Then faster. Then impossibly fast.
0:10-0:20 — Flash of frozen city. Pedestrians like statues. A cold blue trail.
0:20-0:25 — Barry. Warm light. Smiling. "Not everything has to be the biggest thing it can be."
0:25-0:35 — Wally's face. The moment he decides. Cut to speed. Cut to running. Cut to faster.
0:35-0:40 — Death. The turn. The silence.
0:40-0:50 — Void. End of time. The ancient figure. "The faster you become..."
0:50-0:55 — Wally holding Barry's face. Silent.
0:55-1:00 — Black. "Thank you for showing me there was no finish line." Title card: THE RUNNER
SOUND: No score until 0:55. Then a single piano note that holds through the title.
```

---

# THUMBNAIL PROMPTS

**[THUMB] — Episode 1**
```
Split portrait, left half: older man in warm amber light, comfortable smile, 
right half: young man in cold blue light, eyes forward and empty, 
center split line as a speed trail, dark background, 
bold text space at bottom, cinematic quality, high contrast
```

**[THUMB] — The Turn Episode**
```
Young Black man from behind, facing massive dark presence, cold blue light, 
vast empty space, tiny figure vs enormous shadow, 
cinematic wide shot, text overlay space at top, 
color grade: cold blue and absolute black
```

**[THUMB] — Final Episode**
```
Single figure at the end of everything, absolute void, cold blue-white outline light, 
the loneliest image possible, text: "THE FINISH LINE" in cold white letters, 
no other elements, the emptiness is the design
```
