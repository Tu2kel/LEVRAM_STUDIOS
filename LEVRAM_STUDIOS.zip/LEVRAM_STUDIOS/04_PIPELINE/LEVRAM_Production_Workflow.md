# LEVRAM STUDIOS — Production Workflow
### Step-by-step pipeline for every project

---

## THE PIPELINE

```
STEP 1 — Story Concept Locked
        ↓
STEP 2 — Character Bibles Written
        ↓
STEP 3 — Pitch Document + World Lore Written
        ↓
STEP 4 — Scene Breakdowns (all 3 acts)
        ↓
STEP 5 — AI Image Prompts Written (characters → environments → key scenes)
        ↓
STEP 6 — Images Generated → sorted into /Assets/Generated_Images/
        ↓
STEP 7 — AI Video Prompts Written per scene
        ↓
STEP 8 — Video Clips Generated → sorted into /Assets/Generated_Video/Clips/
        ↓
STEP 9 — Narration / Dialogue / Voiceover Written
        ↓
STEP 10 — Soundtrack Emotional Direction Finalized
        ↓
STEP 11 — Episode Cut Together
        ↓
STEP 12 — Thumbnail Generated (use THUMB prompts from AI_PROMPTS file)
        ↓
STEP 13 — Title, Description, Tags Written
        ↓
STEP 14 — Upload to YouTube
        ↓
STEP 15 — Archive final cut to /Exports/Archive/
```

---

## AI TOOLS REFERENCE

| Tool | Use For | Notes |
|---|---|---|
| Midjourney | Character sheets, environments, key scenes | Add `--ar 16:9 --style raw --v 6` |
| DALL-E 3 | Quick concept images, thumbnails | Good for text in images |
| Stable Diffusion | Batch generation, style consistency | Use LEVRAM LoRA when trained |
| Runway Gen-3 | Short video clips, scene generation | Best for emotional slow scenes |
| Sora | Longer sequences, environment establishing shots | Best for cosmic/void sequences |
| Kling | Speed sequences, action | Best motion blur handling |
| ElevenLabs | Voiceover / narration | Wally voice: cold, measured, no warmth |
| Suno / Udio | Soundtrack generation | Use emotional direction guides |
| CapCut / Premiere | Final edit assembly | |
| GitHub | All project files, prompts, scripts | This repo |

---

## NAMING CONVENTIONS

All files follow this pattern:
`[PROJECT]_[TYPE]_[SUBJECT]_[VERSION].md`

Examples:
- `RUNNER_SCRIPT_ACT1_v1.md`
- `RUNNER_IMGPROMPT_WALLY_Portrait.md`
- `RUNNER_VIDPROMPT_Scene04_Death.md`
- `RUNNER_EP03_Concept_v1.md`

Generated assets:
- `RUNNER_IMG_Wally_FullBody_001.png`
- `RUNNER_VID_SpeedSequence_001.mp4`

---

## EPISODE UPLOAD CHECKLIST

Before every upload:
- [ ] Video exported at 4K if possible, minimum 1080p
- [ ] Thumbnail is 1280x720, under 2MB
- [ ] Title includes a hook — not just the episode name
- [ ] Description includes: story context, LEVRAM Studios credit, next episode tease
- [ ] Tags include: dark superhero, original story, LEVRAM, villain POV, [character name]
- [ ] End screen set up for next episode
- [ ] Pinned comment written and ready

---

## GITHUB WORKFLOW

```bash
# First time setup
git clone https://github.com/[YOUR_USERNAME]/LEVRAM_STUDIOS.git
cd LEVRAM_STUDIOS

# Every time you add new files or update
git add .
git commit -m "Add [what you added]"
git push origin main

# Suggested commit message format:
# "Add RUNNER character bible - Wally v1"
# "Update RUNNER AI prompts - key scenes"
# "Add RUNNER EP03 concept"
```

---

## CLAUDE PROJECT INSTRUCTIONS

Paste the contents of `00_BIBLE/LEVRAM_Master_System_Prompt.md` into the Claude Project Instructions field.

Upload key files to the Claude Project Files section:
1. `LEVRAM_Core_Philosophy.md`
2. `LEVRAM_Visual_Identity.md`
3. `LEVRAM_Writing_Rules.md`
4. The active project's Pitch Document
5. The active project's Character Bibles

Claude will reference all of these automatically in every conversation.
